<?php
// includes/header.php
// Usage : <?php $page = 'index'; require 'includes/header.php'; ?>
$page = $page ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secrito<?php echo $pageTitle ? ' — ' . htmlspecialchars($pageTitle) : ''; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Image Preview -->
<div class="image-preview" id="imagePreview">
    <img id="previewImg" src="" alt="Preview">
</div>

<!-- HEADER -->
<header class="header">
    <a href="index.php" class="logo">
        <img src="images/secrito_logo.png" alt="Secrito Logo">
    </a>
    <nav class="navbar">
        <a href="index.php"   <?php echo $page === 'index'   ? 'class="active-nav"' : ''; ?>>Accueil</a>
        <a href="menu.php"    <?php echo $page === 'menu'    ? 'class="active-nav"' : ''; ?>>Menu</a>
        <a href="contact.php" <?php echo $page === 'contact' ? 'class="active-nav"' : ''; ?>>Contact</a>
    </nav>
    <div class="icon">
        <div class="fas fa-shopping-cart" id="cart-btn"></div>
    </div>
</header>
