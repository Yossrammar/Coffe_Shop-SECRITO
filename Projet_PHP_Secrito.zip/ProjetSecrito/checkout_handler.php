<?php
// ============================================================
//  checkout_handler.php — Enregistrement commande (appel AJAX)
//  Reçoit JSON depuis main.js, sauvegarde en BD, retourne JSON
// ============================================================

require_once 'config/config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

// Lire le body JSON
$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['items']) || !is_array($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Panier vide.']);
    exit;
}

$nomClient  = htmlspecialchars(trim($data['nom']       ?? 'Client'), ENT_QUOTES, 'UTF-8');
$telephone  = htmlspecialchars(trim($data['telephone'] ?? ''),       ENT_QUOTES, 'UTF-8');
$items      = $data['items'];

// Calculer le total côté serveur (sécurité)
$total = 0;
foreach ($items as $item) {
    $prix = (float)($item['prix'] ?? 0);
    $qty  = max(1, (int)($item['qty'] ?? 1));
    $total += $prix * $qty;
}

try {
    $pdo = getDB();
    $pdo->beginTransaction();

    // Insérer la commande
    $stmt = $pdo->prepare(
        "INSERT INTO commandes (nom_client, telephone, total) VALUES (:nom, :tel, :total)"
    );
    $stmt->execute([':nom' => $nomClient, ':tel' => $telephone, ':total' => $total]);
    $commandeId = $pdo->lastInsertId();

    // Insérer les lignes
    $stmtItem = $pdo->prepare(
        "INSERT INTO commande_items (commande_id, produit_id, nom_produit, prix_unit, quantite)
         VALUES (:cid, :pid, :nom, :prix, :qty)"
    );

    foreach ($items as $item) {
        $stmtItem->execute([
            ':cid'  => $commandeId,
            ':pid'  => isset($item['id']) ? (int)$item['id'] : null,
            ':nom'  => htmlspecialchars(trim($item['name'] ?? ''), ENT_QUOTES, 'UTF-8'),
            ':prix' => (float)($item['prix'] ?? 0),
            ':qty'  => max(1, (int)($item['qty'] ?? 1)),
        ]);
    }

    $pdo->commit();

    echo json_encode([
        'success'     => true,
        'message'     => 'Commande enregistrée avec succès !',
        'commande_id' => $commandeId,
        'total'       => $total,
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('Secrito checkout error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Veuillez réessayer.']);
}
exit;
