<?php
// ============================================================
//  config/config.php — Configuration générale du site
// ============================================================

define('SITE_NAME', 'Secrito');
define('SITE_URL',  'http://localhost:8080/ProjetSecrito');   // ← URL XAMPP

// Sécurité : démarre la session si pas déjà démarrée
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Chargement de la connexion DB
require_once __DIR__ . '/db.php';

// Fonction utilitaire : nettoyer les entrées utilisateur
function clean(string $val): string {
    return htmlspecialchars(trim($val), ENT_QUOTES, 'UTF-8');
}
